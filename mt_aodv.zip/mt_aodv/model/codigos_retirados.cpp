 //Modificação que tinha sido realizada para o origem da mensagem

  //std::cout<<" RoutingProtocol::RecvRequest () - Cria uma entrada de tabela vazia"<<std::endl;

  //RoutingTableEntry toOrigin;
  bool achou =false;
  uint indice_tabela=0;

  //std::cout<<" RoutingProtocol::RecvRequest () - Verifica se possui origem e gateway nas tabelas"<<std::endl;

  for (uint i=0;i<m_routingTableList.size();i++){
    if(m_routingTableList[i].LookupGateway(origin,src,toOrigin)){
      achou=true;
      indice_tabela=i;
      break;
    }
  }

  if (achou ==false)
    { 
      std::cout<<" RoutingProtocol::RecvRequest () - Se nao encontrar nenhuma tabela -adiciona na tabela 0"<<std::endl;

      Ptr<NetDevice> dev = m_ipv4->GetNetDevice (m_ipv4->GetInterfaceForAddress (receiver));
      RoutingTableEntry newEntry (/*device=*/ dev, /*dst=*/ origin, /*validSeno=*/ true, /*seqNo=*/ rreqHeader.GetOriginSeqno (),
                                              /*iface=*/ m_ipv4->GetAddress (m_ipv4->GetInterfaceForAddress (receiver), 0), /*hops=*/ hop,
                                              /*nextHop*/ src, /*timeLife=*/ Time ((2 * m_netTraversalTime - 2 * hop * m_nodeTraversalTime)));
    
      m_routingTableList[0].AddRoute(newEntry); //tah errado

    }
  else
    {
      if (toOrigin.GetValidSeqNo ())
        {
          if (int32_t (rreqHeader.GetOriginSeqno ()) - int32_t (toOrigin.GetSeqNo ()) > 0)
            {
              toOrigin.SetSeqNo (rreqHeader.GetOriginSeqno ());
            }
        }
      else
        {
          toOrigin.SetSeqNo (rreqHeader.GetOriginSeqno ());
        }
      toOrigin.SetValidSeqNo (true);
      toOrigin.SetNextHop (src);
      toOrigin.SetOutputDevice (m_ipv4->GetNetDevice (m_ipv4->GetInterfaceForAddress (receiver)));
      toOrigin.SetInterface (m_ipv4->GetAddress (m_ipv4->GetInterfaceForAddress (receiver), 0));
      toOrigin.SetHop (hop);
      toOrigin.SetLifeTime (std::max (Time (2 * m_netTraversalTime - 2 * hop * m_nodeTraversalTime),
                                      toOrigin.GetLifeTime ()));
      //m_routingTable.Update (toOrigin);

      //09MAR
      //m_routingTableList[0].Update(toOrigin);

      m_routingTableList[indice_tabela].Update(toOrigin);

      //m_nb.Update (src, Time (AllowedHelloLoss * HelloInterval));
    }
-------------------------------------------------
//Modificação para o vizinho, retirei

  bool achou2=false;
  RoutingTableEntry toNeighbor;
  for (uint i=0;i<m_routingTableList.size();i++){
    if(m_routingTableList[0].LookupRoute(src,toNeighbor)){
      achou2=true;
      indice_tabela=i;
      break;
    }
  }

  if (!achou2)
    {
      NS_LOG_DEBUG ("Neighbor:" << src << " not found in routing table. Creating an entry");
      Ptr<NetDevice> dev = m_ipv4->GetNetDevice (m_ipv4->GetInterfaceForAddress (receiver));
      RoutingTableEntry newEntry (dev, src, false, rreqHeader.GetOriginSeqno (),
                                  m_ipv4->GetAddress (m_ipv4->GetInterfaceForAddress (receiver), 0),
                                  1, src, m_activeRouteTimeout);
      //m_routingTable.AddRoute (newEntry);


      //09MAR
      m_routingTableList[0].AddRoute(newEntry);

    }
  else
    {
      toNeighbor.SetLifeTime (m_activeRouteTimeout);
      toNeighbor.SetValidSeqNo (false);
      toNeighbor.SetSeqNo (rreqHeader.GetOriginSeqno ());
      toNeighbor.SetFlag (VALID);
      toNeighbor.SetOutputDevice (m_ipv4->GetNetDevice (m_ipv4->GetInterfaceForAddress (receiver)));
      toNeighbor.SetInterface (m_ipv4->GetAddress (m_ipv4->GetInterfaceForAddress (receiver), 0));
      toNeighbor.SetHop (1);
      toNeighbor.SetNextHop (src);

      //09MAR
      //m_routingTableList[0].Update(toNeighbor);

      m_routingTableList[indice_tabela].Update(toNeighbor);

      //m_routingTable.Update (toNeighbor);
    }
  m_nb.Update (src, Time (m_allowedHelloLoss * m_helloInterval));

  --------------------------------------------------------


 std::vector<int> hops_toDst;
  std::vector<int> tabelas_toDst;
  std::vector<int> hops_toOrigin;
  std::vector<int> tabelas_toOrigin;
  int c=0;
  int cHop=99;
  //int d=0;
  //int dHop=99;
  
  for (std::vector<RoutingTable>::iterator it = m_routingTableList.begin();it!=m_routingTableList.end();it++)
  { RoutingTableEntry toDst2;
    if (it->LookupValidRoute (dst, toDst2))
    { 
      if (toDst2.GetHop()<cHop)
        {
          cHop=toDst2.GetHop();
        }
    }
  }
  for (std::vector<RoutingTable>::iterator it = m_routingTableList.begin();it!=m_routingTableList.end();it++)
  { RoutingTableEntry toDst2;
    if (it->LookupValidRoute (dst, toDst2))
    { 
      if (toDst2.GetHop()==cHop)
        {
          tabelas_toDst.push_back(c);
        }
    }
    c++;
  }


  for (uint i=0;i<tabelas_toDst.size();i++)
  {
    RoutingTableEntry toDst;
    if (m_routingTableList[tabelas_toDst[i]].LookupRoute (dst, toDst))
    {
      /*
       * The Destination Sequence number for the requested destination is set to the maximum of the corresponding value
       * received in the RREQ message, and the destination sequence value currently maintained by the node for the requested destination.
       * However, the forwarding node MUST NOT modify its maintained value for the destination sequence number, even if the value
       * received in the incoming RREQ is larger than the value currently maintained by the forwarding node.
       */
      if ((rreqHeader.GetUnknownSeqno () || (int32_t (toDst.GetSeqNo ()) - int32_t (rreqHeader.GetDstSeqno ()) >= 0))
          && toDst.GetValidSeqNo () )
        {
          if (!rreqHeader.GetDestinationOnly () && toDst.GetFlag () == VALID)
            {
              m_routingTableList[tabelas_toDst[i]].LookupRoute (origin, toOrigin);
              SendReplyByIntermediateNode (toDst, toOrigin, rreqHeader.GetGratuitousRrep ());
              return;
            }
          rreqHeader.SetDstSeqno (toDst.GetSeqNo ());
          rreqHeader.SetUnknownSeqno (false);
        }
      }
    }