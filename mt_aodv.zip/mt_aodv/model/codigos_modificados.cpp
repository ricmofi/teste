{
 //std::cout<<Simulator::Now()<<" RoutingProtocol::RouteRequestTimerExpire (Ipv4Address dst) "<<dst<<std::endl;

  NS_LOG_LOGIC (this);
  //RoutingTableEntry toDst;
  /*if (m_routingTable.LookupValidRoute (dst, toDst))
    {
      SendPacketFromQueue (dst, toDst.GetRoute ());
      NS_LOG_LOGIC ("route to " << dst << " found");
      return;
    }*/

  //09MAR
  bool achou=false;
  std::vector<RoutingTableEntry> toDst_pos2;
  std::vector<RoutingTableEntry> toDst_pos;
  std::vector<int> tabelas_pos;
  for (uint j=0;j<m_routingTableList.size();j++){
    RoutingTableEntry toDst;
    if (m_routingTableList[j].LookupValidRoute (dst, toDst))   
    { 
      achou=true;
      toDst_pos.push_back(toDst);
      
      }
    else{
      toDst_pos2.push_back(toDst);  
      tabelas_pos.push_back(j);   
    } 
  }
  for (uint j=0;j<toDst_pos.size();j++)
  {
    SendPacketFromQueue (dst, toDst_pos[j].GetRoute ());
  }

  if (achou)
//    if (m_routingTableList[0].LookupValidRoute (dst, toDst))
    { 
   //std::cout<<" RoutingProtocol::RouteRequestTimerExpire ACHOU "<<dst<<std::endl;

      NS_LOG_LOGIC ("route to " << dst << " found");
      return;
    }

  /*
   *  If a route discovery has been attempted RreqRetries times at the maximum TTL without
   *  receiving any RREP, all data packets destined for the corresponding destination SHOULD be
   *  dropped from the buffer and a Destination Unreachable message SHOULD be delivered to the application.
   */

  for (uint k=0;k<toDst_pos2.size();k++)
  {
    if (toDst_pos2[k].GetRreqCnt () == m_rreqRetries)
    {
      NS_LOG_LOGIC ("route discovery to " << dst << " has been attempted RreqRetries (" << m_rreqRetries << ") times with ttl " << m_netDiameter);
      m_addressReqTimer.erase (dst);
     //std::cout<<"RouteRequestTimerExpire 1 _routingTable.DeleteRoute (dst) , m_addressReqTimer.erase"<<std::endl; 
      //09MAR
      m_routingTableList[tabelas_pos[k]].DeleteRoute (dst);   
      NS_LOG_DEBUG ("Route not found. Drop all packets with dst " << dst);
      m_queue.DropPacketWithDst (dst);
      return;
    }

  if (toDst_pos2[k].GetFlag () == IN_SEARCH)
    { 
     //std::cout<<" RoutingProtocol::RouteRequestTimerExpire IN_SEARCH"<<dst<<std::endl;
      NS_LOG_LOGIC ("Resend RREQ to " << dst << " previous ttl " << toDst_pos2[k].GetHop ());
      SendRequest (dst);
    }

  else
    {
      NS_LOG_DEBUG ("Route down. Stop search. Drop packet with destination " << dst);
     //std::cout<<"RouteRequestTimerExpire 2 - m_routingTable.DeleteRoute (dst) , m_addressReqTimer.erase"<<std::endl; 
      
      m_addressReqTimer.erase (dst);
      //09MAR
      m_routingTableList[tabelas_pos[k]].DeleteRoute (dst);
      //m_routingTable.DeleteRoute (dst);
      m_queue.DropPacketWithDst (dst);
    }
  }
}




-------------------------------------
fORWARDING

bool
RoutingProtocol::Forwarding (Ptr<const Packet> p, const Ipv4Header & header,
                             UnicastForwardCallback ucb, ErrorCallback ecb)
{
  std::cout<<" RoutingProtocol::Forwarding Destination" <<header.GetDestination ()<<std::endl;
  //std::cout<<" Forwarding - Tamanho da tabela "<<m_routingTableList.size()<<std::endl; 

  NS_LOG_FUNCTION (this);
  Ipv4Address dst = header.GetDestination ();
  Ipv4Address origin = header.GetSource ();

  //10MAR
  for (uint i=0;i<m_routingTableList.size();i++){
    m_routingTableList[i].Purge ();
  }

  //m_routingTable.Purge ();
  RoutingTableEntry toDst;

  //31MAR
  std::vector<int> hops_toDst;
  std::vector<int> tabelas_pos;
  int c=0;
  int e=99;

  for (std::vector<RoutingTable>::iterator it = m_routingTableList.begin();it!=m_routingTableList.end();it++)
  {
    if (it->LookupRoute (dst, toDst))
    { 
      if (toDst.GetFlag () == VALID)
       {
      Ptr<Ipv4Route> rota = toDst.GetRoute ();
      if(rota->GetGateway()==origin){
        continue; //tentar evitar loops
        }

      if (toDst.GetHop()<e)
        {
          e=toDst.GetHop();
        }
      }
    }
  }

  for (std::vector<RoutingTable>::iterator it = m_routingTableList.begin();it!=m_routingTableList.end();it++)
  {
    if (it->LookupRoute (dst, toDst))
    { 
      if (toDst.GetFlag () == VALID)
       {
        if (toDst.GetHop()==e)
          {
            tabelas_pos.push_back(c);

          }
        }
    }
    c++;
  }


  /*for (std::vector<RoutingTable>::iterator it = m_routingTableList.begin();it!=m_routingTableList.end();it++)
  {
    if (it->LookupRoute (dst, toDst))
    { if (toDst.GetFlag () == VALID){
      tabelas_pos.push_back(c);
      hops_toDst.push_back(toDst.GetHop());
      std::cout<<"valor de C "<<c<<std::endl;

      UpdateRouteLifeTimei (origin, m_activeRouteTimeout,c);
      UpdateRouteLifeTimei (dst, m_activeRouteTimeout,c);   

    }
    }
    c++;
  }*/
  /*int d=0;
  if (hops_toDst.size()>0){
    for (uint i=1;i<hops_toDst.size();i++)
    {
      std::cout<<"valor do hop "<<hops_toDst[i]<<std::endl;

      if (hops_toDst[i]<hops_toDst[i-1])
      {
        d=tabelas_pos[i];
      }
      else if (hops_toDst[i]>hops_toDst[i-1])
      {
        d=tabelas_pos[i-1];
      }
      else{
        c=rand()%tabelas_pos.size();  
        d=tabelas_pos[c];
      }
    }
  }*/

  //std::cout<<"valor de D "<<tabelas_pos.size()<<std::endl;

  int d=0;
  if (tabelas_pos.size()>0){
    c=rand()%tabelas_pos.size();  
    d=tabelas_pos[c];
  }

//m_routingTableList[d].LookupRoute(dst,toDst);



  //std::cout<<"valor de d "<<d<<std::endl;
  
//-----------------

  //for (uint i=0;i<m_routingTableList.size();i++){

    if (m_routingTableList[d].LookupRoute (dst, toDst))

    //if (m_routingTable.LookupRoute (dst, toDst))
      {
        if (toDst.GetFlag () == VALID)
          {
            Ptr<Ipv4Route> route = toDst.GetRoute ();
            NS_LOG_LOGIC (route->GetSource () << " forwarding to " << dst << " from " << origin << " packet " << p->GetUid ());

            /*
             *  Each time a route is used to forward a data packet, its Active Route
             *  Lifetime field of the source, destination and the next hop on the
             *  path to the destination is updated to be no less than the current
             *  time plus ActiveRouteTimeout.
             */

            //std::cout<<"UpdateRouteLifeTimei do Forwarding"<< std::endl;

            UpdateRouteLifeTimei (origin, m_activeRouteTimeout,d);
            UpdateRouteLifeTimei (dst, m_activeRouteTimeout,d);
            UpdateRouteLifeTimei (route->GetGateway (), m_activeRouteTimeout,d);



            /*
             *  Since the route between each originator and destination pair is expected to be symmetric, the
             *  Active Route Lifetime for the previous hop, along the reverse path back to the IP source, is also updated
             *  to be no less than the current time plus ActiveRouteTimeout
             */
            RoutingTableEntry toOrigin;

            //10MAR
            m_routingTableList[d].LookupRoute (origin, toOrigin);

            //m_routingTable.LookupRoute (origin, toOrigin);

            //std::cout<<"UpdateRouteLifeTimei do Forwarding2"<< std::endl;

            UpdateRouteLifeTimei (toOrigin.GetNextHop (), m_activeRouteTimeout,d);

            //std::cout<<"Update m_nb do Forwarding"<< std::endl;
            //**IMPORTANTE - Foi retirado atualizacao dos vizinhos pq dava problema com mais
            //de uma tabela - MELHORAR para atualizar somente da tabela válida
            //m_nb.Update (route->GetGateway (), m_activeRouteTimeout);
            m_nb.Update (toOrigin.GetNextHop (), m_activeRouteTimeout);

            ucb (route, p, header);
            return true;
          }
        else
          {
            if (toDst.GetValidSeqNo ())
              {
                SendRerrWhenNoRouteToForward (dst, toDst.GetSeqNo (), origin);
                NS_LOG_DEBUG ("Drop packet " << p->GetUid () << " because no route to forward it.");
                return false;
              }
          }
      }
    //}
  NS_LOG_LOGIC ("route not found to " << dst << ". Send RERR message.");
  NS_LOG_DEBUG ("Drop packet " << p->GetUid () << " because no route to forward it.");
  SendRerrWhenNoRouteToForward (dst, 0, origin);
  return false;
}